# Nova Assistant (Android)

Voice assistant + chatbot + draw-to-open launcher. Opens ANY installed app directly by package name (no links).

## Features
- Voice: tap the orb, say "open Instagram" (fuzzy-matches your real installed apps)
- Chatbot: Wikipedia answers, time/date/math; add an Anthropic API key in ⚙️ for full AI
- Draw: draw a shape, save it for any installed app, redraw to launch it

## Build the APK on GitHub (no Android Studio needed)
1. Create a new GitHub repo and upload everything *inside* the `nova` folder so that `.github`, `app`, `build.gradle.kts` sit at the repo root (the `.github` folder must be at the top level, or the build won't run).
2. Open the **Actions** tab -> "Build APK" -> wait ~5 min.
3. Open the finished run -> **Artifacts** -> download `Nova-debug-apk`, unzip, install the APK.

Or open in Android Studio and press Run.
